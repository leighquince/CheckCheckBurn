package nl.starapple.poker;
public enum CardSuit {
	SPADES, HEARTS, CLUBS, DIAMONDS
}
